<div class="modal " id="offlinemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" >

<div class="modal-dialog modal-dialog-centered" role="document">

  <div class="modal-content">

      <div class="modal-header">

        <h5 class="modal-title" id="exampleModalLongTitle">{{__("Administrators are offline")}}</h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

            <span aria-hidden="true">&times;</span>

        </button>

      </div>

      <div class="modal-body" style="text-align:left">

        <p text-center>{{__("Purchase-sale form disabled because the administrators are not online, for more information, please read the message at the header")}} </p>

        <div class="modal-footer">

          <button  type="button" class="btn btn-secondary custom_pay_validator" style="background-color:orangered; color:white; font-weight:normal" data-dismiss="modal">OK</button>
      
        </div>

      </div>

  </div>

</div>

</div>