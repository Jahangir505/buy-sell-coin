<div class="container flash">

    @include('flash')

</div>