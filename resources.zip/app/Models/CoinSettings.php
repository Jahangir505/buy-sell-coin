<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class CoinSettings extends Model
{
	protected $table =	'coin_settings';
}
